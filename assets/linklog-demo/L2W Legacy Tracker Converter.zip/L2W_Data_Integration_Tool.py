import pandas as pd
import re
from pathlib import Path
from datetime import datetime, timedelta
from tkinter import Tk, filedialog

# ============================================================
# L2W CSV Converter - HTML Date-Safe Version
#
# Input:
#   L2W Sample Client Tracker.csv
#
# Output:
#   SP_Clients.csv
#   SP_Interaction_Log.csv
#
# Fixes:
#   1. Outputs exact filenames expected by the HTML.
#   2. Keeps the full 54-column client schema.
#   3. Removes internal line breaks inside CSV cells.
#   4. Forces all date fields used by the HTML into YYYY-MM-DD.
#   5. Fills 3mo / 6mo / 12mo / Next_Followup_Date with valid dates.
# ============================================================

RAW_FILE = "L2W Sample Client Tracker.csv"

OUTPUT_CLIENTS_FILE = "SP_Clients.csv"
OUTPUT_LOG_FILE = "SP_Interaction_Log.csv"

CLIENT_COLUMNS = ['Client_ID', 'Full_Name', 'Phone', 'Birth_Date', 'Age', 'Enrollment_Date', 'Status', 'Transportation', 'Referral_Source', 'File_Location', 'Reason_of_Discontinue', 'Referral_Reason', 'Accessibility_Needs', 'Hobbies', 'Preferences', '3mo_Due_Date', '6mo_Due_Date', '12mo_Due_Date', 'Progress', 'Call_Schedule', 'Programs_Attending', 'Latest_Followup_ID', 'Latest_Followup_Date', 'Latest_Followup_Type', 'Latest_Call_Attempt', 'Latest_Call_Outcome', 'Latest_Program_Participation', 'Latest_Lack_Companionship', 'Latest_Left_Out', 'Latest_Isolated', 'Latest_Conversation_Notes', 'Latest_Mood_Tags', 'Latest_Topic_Tags', 'Latest_Barrier_Tags', 'Next_Followup_Date', 'Followup_Method', 'Reminder_Notes', 'Latest_Staff_Name', 'Followup_Scheduled', 'Contact_Attempt', 'Scheduled_DateTime', 'Channel', 'Next_Followup_Type', 'Age_Range', 'Gender', 'Pronouns', 'Identity_Tags', 'Receives_GIS_GAINS', 'Receives_Subsidy_Funding', 'Financial_Notes', 'Social_Activity_At_Intake', 'Social_Activity_Details', 'Intake_Notes', 'Key_Barriers']
LOG_COLUMNS = ['Log_ID', 'Date_of_Call', 'Client_ID', 'Client_Name', 'Interaction_Type', 'Outcome', 'Staff_Notes']


def clean_text(x):
    if pd.isna(x):
        return ""
    text = str(x)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\n+", " | ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def parse_date_obj(x):
    x = clean_text(x)
    if not x:
        return None

    # Try common Canadian / spreadsheet formats.
    candidates = [
        dict(errors="coerce"),
        dict(errors="coerce", dayfirst=False),
        dict(errors="coerce", dayfirst=True),
    ]

    for kwargs in candidates:
        try:
            dt = pd.to_datetime(x, **kwargs)
            if not pd.isna(dt):
                return dt.to_pydatetime().date()
        except Exception:
            pass

    return None


def parse_date(x):
    d = parse_date_obj(x)
    if not d:
        return ""
    return d.strftime("%Y-%m-%d")


def add_days(date_str, days):
    d = parse_date_obj(date_str)
    if not d:
        return ""
    return (d + timedelta(days=days)).strftime("%Y-%m-%d")


def bool_yes_no(x):
    x_clean = clean_text(x)
    x_lower = x_clean.lower()

    if not x_lower:
        return ""

    if x_lower in ["yes", "y", "true", "1"]:
        return "Yes"

    if x_lower in ["no", "n", "false", "0"]:
        return "No"

    return x_clean


def infer_status(discharge_value):
    value = clean_text(discharge_value).lower()

    if value in ["complete", "completed", "yes", "discharged"]:
        return "Graduated"

    if value in ["discontinued", "declined", "withdrawn"]:
        return "Discontinued"

    # HTML expects Active / Graduated / Discontinued.
    return "Active"


def infer_reason_of_discontinue(discharge_value):
    value = clean_text(discharge_value).lower()

    if value in ["complete", "completed", "yes", "discharged"]:
        return "Completed / Discharged"

    if value in ["discontinued", "declined", "withdrawn"]:
        return clean_text(discharge_value)

    return ""


def normalize_outcome(x):
    value = clean_text(x).lower()

    if value in ["complete", "completed", "yes", "done"]:
        return "Complete"

    if value in ["left vm", "left voicemail", "voicemail", "no answer"]:
        return "No Answer"

    if value in ["reschedule", "rescheduled"]:
        return "Rescheduled"

    if value in ["discontinue", "discontinued", "declined", "decline"]:
        return "Discontinued"

    if value in ["pending", ""]:
        return ""

    # Unknown values can break filtering less often if left blank.
    return ""


def split_reason_barriers(reason):
    text = clean_text(reason)
    parts = [p.strip() for p in re.split(r",|;", text) if p.strip()]
    return "; ".join(parts)


def safe_cell(value):
    return clean_text(value)


def build_clients(raw_df):
    rows = []

    for i, r in raw_df.iterrows():
        first_name = clean_text(r.get("First Name"))
        surname = clean_text(r.get("Surname"))
        full_name = f"{first_name} {surname}".strip()

        reason = clean_text(r.get("Reason for Referral"))
        starting_programs = clean_text(r.get("Starting Programs"))

        intake_completed = parse_date(r.get("In-Take Completed"))
        referral_received = parse_date(r.get("Referral Received"))

        # Enrollment_Date is heavily used by the HTML.
        # If intake date is missing, use referral date.
        # If both are missing, use a safe generated fallback date.
        enrollment_date = intake_completed or referral_received or f"2025-01-{(i % 28) + 1:02d}"

        three_month = add_days(enrollment_date, 90)
        six_month = add_days(enrollment_date, 180)
        twelve_month = add_days(enrollment_date, 365)

        status = infer_status(r.get("Discharged"))
        call_outcome = normalize_outcome(r.get("Check-In Call"))

        row = {col: "" for col in CLIENT_COLUMNS}

        row.update({
            "Client_ID": clean_text(r.get("L2WB Client Code")) or f"GTSC{i+1}",
            "Full_Name": full_name or f"Client {i+1}",
            "Phone": clean_text(r.get("Phone Number")),
            "Enrollment_Date": enrollment_date,
            "Status": status,
            "Transportation": "",
            "Referral_Source": clean_text(r.get("Agency")),
            "File_Location": "",
            "Reason_of_Discontinue": infer_reason_of_discontinue(r.get("Discharged")),
            "Referral_Reason": reason,
            "Accessibility_Needs": "",
            "Hobbies": "",
            "Preferences": "",
            "3mo_Due_Date": three_month,
            "6mo_Due_Date": six_month,
            "12mo_Due_Date": twelve_month,
            "Progress": "N/A" if status in ["Graduated", "Discontinued"] else "Active",
            "Call_Schedule": "",
            "Programs_Attending": starting_programs,
            "Latest_Followup_ID": "",
            "Latest_Followup_Date": enrollment_date,
            "Latest_Followup_Type": "Check-In Call" if call_outcome else "",
            "Latest_Call_Attempt": "0" if call_outcome == "Complete" else ("1" if call_outcome else "0"),
            "Latest_Call_Outcome": call_outcome,
            "Latest_Program_Participation": "",
            "Latest_Lack_Companionship": "",
            "Latest_Left_Out": "",
            "Latest_Isolated": "",
            "Latest_Conversation_Notes": (
                clean_text(r.get("Client Participation  and Outcome Form 12 Mo"))
                or clean_text(r.get("Client Participation  and Outcome Form 6 Mo"))
            ),
            "Latest_Mood_Tags": "",
            "Latest_Topic_Tags": "",
            "Latest_Barrier_Tags": "",
            # Important: Next_Followup_Date must be valid or the HTML date logic can fail.
            "Next_Followup_Date": three_month if status == "Active" else "",
            "Followup_Method": "Call",
            "Reminder_Notes": "",
            "Latest_Staff_Name": "",
            "Followup_Scheduled": "No",
            "Contact_Attempt": "0" if call_outcome == "Complete" else ("1" if call_outcome else "0"),
            "Scheduled_DateTime": "",
            "Channel": "Call",
            "Next_Followup_Type": "3-Month Check-in" if status == "Active" else "",
            "Age_Range": "",
            "Gender": "",
            "Pronouns": "",
            "Identity_Tags": "",
            "Receives_GIS_GAINS": "",
            "Receives_Subsidy_Funding": bool_yes_no(r.get("Subsidy Requested?")),
            "Financial_Notes": "",
            "Social_Activity_At_Intake": "",
            "Social_Activity_Details": "",
            "Intake_Notes": clean_text(r.get("Intake Status & Notes")),
            "Key_Barriers": split_reason_barriers(reason),
        })

        row = {k: safe_cell(v) for k, v in row.items()}
        rows.append(row)

    return pd.DataFrame(rows, columns=CLIENT_COLUMNS)


def build_interaction_logs(raw_df):
    rows = []
    log_no = 1

    for i, r in raw_df.iterrows():
        client_id = clean_text(r.get("L2WB Client Code")) or f"GTSC{i+1}"
        first_name = clean_text(r.get("First Name"))
        surname = clean_text(r.get("Surname"))
        client_name = f"{first_name} {surname}".strip() or f"Client {i+1}"

        intake_date = parse_date(r.get("Referral Received")) or parse_date(r.get("In-Take Completed")) or f"2025-01-{(i % 28) + 1:02d}"
        six_date = add_days(intake_date, 180)
        twelve_date = add_days(intake_date, 365)

        check_outcome = normalize_outcome(r.get("Check-In Call"))

        event_specs = [
            {
                "Interaction_Type": "Intake / First Contact",
                "Date_of_Call": intake_date,
                "Staff_Notes": clean_text(r.get("Intake Status & Notes")),
                "Outcome": "Complete" if clean_text(r.get("Intake Status & Notes")) else "",
            },
            {
                "Interaction_Type": "Check-In Call",
                "Date_of_Call": intake_date,
                "Staff_Notes": "",
                "Outcome": check_outcome,
            },
            {
                "Interaction_Type": "6-Month Check-in",
                "Date_of_Call": six_date,
                "Staff_Notes": clean_text(r.get("Client Participation  and Outcome Form 6 Mo")),
                "Outcome": "Complete" if clean_text(r.get("Client Participation  and Outcome Form 6 Mo")) else "",
            },
            {
                "Interaction_Type": "12-Month Check-in",
                "Date_of_Call": twelve_date,
                "Staff_Notes": clean_text(r.get("Client Participation  and Outcome Form 12 Mo")),
                "Outcome": "Complete" if clean_text(r.get("Client Participation  and Outcome Form 12 Mo")) else "",
            },
        ]

        for event in event_specs:
            if event["Staff_Notes"] or event["Outcome"]:
                rows.append({
                    "Log_ID": f"LOG-{log_no:04d}",
                    "Date_of_Call": safe_cell(event["Date_of_Call"]),
                    "Client_ID": safe_cell(client_id),
                    "Client_Name": safe_cell(client_name),
                    "Interaction_Type": safe_cell(event["Interaction_Type"]),
                    "Outcome": safe_cell(event["Outcome"]),
                    "Staff_Notes": safe_cell(event["Staff_Notes"]),
                })
                log_no += 1

    return pd.DataFrame(rows, columns=LOG_COLUMNS)


def main():
    # Open file picker so users do not need to rename files manually
    Tk().withdraw()

    selected_file = filedialog.askopenfilename(
        title="Select L2W Tracker CSV",
        filetypes=[("CSV Files", "*.csv")]
    )

    if not selected_file:
        print("No file selected.")
        return

    raw_path = Path(selected_file)

    raw_df = pd.read_csv(raw_path)

    clients_df = build_clients(raw_df)
    logs_df = build_interaction_logs(raw_df)

    # Save output files into the same folder as the selected CSV
    output_dir = raw_path.parent

    clients_output = output_dir / OUTPUT_CLIENTS_FILE
    logs_output = output_dir / OUTPUT_LOG_FILE

    clients_df.to_csv(clients_output, index=False, lineterminator="\n")
    logs_df.to_csv(logs_output, index=False, lineterminator="\n")

    print("Conversion finished.")
    print(f"Input: {raw_path}")
    print(f"Output 1: {clients_output}")
    print(f"Output 2: {logs_output}")
    print(f"Client rows: {len(clients_df)}")
    print(f"Client columns: {len(CLIENT_COLUMNS)}")
    print(f"Log rows: {len(logs_df)}")
    print(f"Log columns: {len(LOG_COLUMNS)}")


if __name__ == "__main__":
    main()
